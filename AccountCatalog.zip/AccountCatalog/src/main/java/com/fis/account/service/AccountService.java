package com.fis.account.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.account.Exception.AccountNotFound;
import com.fis.account.dao.AccountDao;
import com.fis.account.model.Account;

@Service
@Transactional
public class AccountService {
	@Autowired
	private AccountDao dao;
	
	public List<Account> getAccounts(){
	
		List<Account> list=dao.findAll();
		if(list.isEmpty()) {
			return null;
			//throw new AccountNotFound("No Accounts found");
		}
		else return list;
	}
	
	
}
