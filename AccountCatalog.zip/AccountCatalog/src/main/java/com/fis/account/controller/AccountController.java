package com.fis.account.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.account.model.Account;
import com.fis.account.model.AccountDTO;
import com.fis.account.service.AccountService;

@RestController
public class AccountController {
	@Autowired
	private AccountService service;
	
	@GetMapping("/accounts")
	public ResponseEntity<AccountDTO> getAccounts(){
		List<Account> list= service.getAccounts();
		AccountDTO dto=new AccountDTO();
		dto.setList(list);
		return new ResponseEntity<AccountDTO>(dto,HttpStatus.OK);
		
	}
}
