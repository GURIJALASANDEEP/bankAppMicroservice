package com.fis.accservice;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.accservice.model.Account;
import com.fis.accservice.service.AccountService;
import com.fis.accservice.dao.AccountDao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fis.accservice.exception.AccountNotFound;
import com.fis.accservice.exception.NoRecordsException;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	AccountDao dao;
	
	@Autowired
	AccountService service;



	
	@Test
	public void testAddAccount() {
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = service.addAccount(account);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	public void testUpdateAccount() {
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		boolean res = service.updateAccount(account);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	@DisplayName("Delete Account")
	public void testDeleteAccount() throws NoRecordsException{
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		
	
		try {
			Optional<Account> custList=Optional.of(account);
	
			Mockito.when(dao.findById(account.getAccNo())).thenReturn(custList);
		Mockito.when(dao.deleteAccount(account.getAccNo())).thenReturn(1);		
		boolean res = service.deleteAccount(account.getAccNo());
		assertTrue(res);
		}
		catch (NoRecordsException e){
        	e.getMessage();
        	
        }
	}
	
	
	
	@Test
	@DisplayName("View Accounts- Successful")
	public void getAll() throws NoRecordsException{
 
		Account account = new Account(1,1234,"savings","xcvh", "ghjn", 567);
		Mockito.when(dao.save(account)).thenReturn(account);
		List<Account> accList=new ArrayList<Account>();
		List<Account> reaccList= new ArrayList<Account>();
        try {
        Mockito.when(dao.findAll()).thenReturn(accList);
       	reaccList = service.getAll();
       	assertEquals(accList, reaccList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
	
	
	

}
