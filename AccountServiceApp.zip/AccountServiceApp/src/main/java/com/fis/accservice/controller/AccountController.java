package com.fis.accservice.controller;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.fis.accservice.model.Account;
import com.fis.accservice.model.AccountDTO;
import com.fis.accservice.service.AccountService;
import com.fis.accservice.exception.AccountNotFound;
import com.fis.accservice.exception.NotEnoughBalance;

@RestController
public class AccountController {

	@Autowired
	private AccountService service;
	
	
	@GetMapping("/getAccounts")
	public ResponseEntity<AccountDTO> getAccounts(){
		AccountDTO dto=new AccountDTO();
		dto.setList(service.getAll());
		return new ResponseEntity<AccountDTO>(dto,HttpStatus.OK);
	}
	
	@PostMapping("/addAccount")
	public ResponseEntity<Object> addAccount(@RequestBody Account acc){
		if(service.addAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	@PostMapping("/updateAccount")
	public ResponseEntity<Object> updateAccount(@RequestBody Account acc){
		if(service.updateAccount(acc)) {
			return new ResponseEntity<Object>(HttpStatus.CREATED);
		}
		else
			return new ResponseEntity<Object>(HttpStatus.BAD_REQUEST);
	}
	
	@DeleteMapping("/deleteAccount/{accNo}")
	public ResponseEntity<Object> deleteAccount(@PathVariable("accNo") int accNo){
		service.deleteAccount(accNo);
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/deleteAll")
	public ResponseEntity<Object> deleteAll(){
		service.deleteAll();
		return new ResponseEntity<Object>("Deleted",HttpStatus.NO_CONTENT);
	}
	
	
	
	@GetMapping("/depositIntoBalance/{accNo}/{depositAmount}")
	public ResponseEntity<Object> depositIntoBalance(@PathVariable("accNo") long accNo,
			@PathVariable("depositAmount") double depositAmount) throws AccountNotFound {
		double updatedbal = service.depositIntoBalance(accNo, depositAmount);
			
			
			return new ResponseEntity<Object>(updatedbal,HttpStatus.OK);
 
	}
	
	@GetMapping("/withdrawFromBalance/{accNo}/{withdrawAmount}")
	public ResponseEntity<Double> withdrawFromBalance(@PathVariable("accNo") long accNo,
			@PathVariable("withdrawAmount") double withdrawAmount) throws AccountNotFound, NotEnoughBalance {
		double updatedbal=service.withdrawFromBalance(accNo, withdrawAmount);
		
		
			return new ResponseEntity<Double>(updatedbal,HttpStatus.OK);
		
	}
	
	@GetMapping("/fundTransfer/{accNoFrom}/{accNoTo}/{amount}")
	public ResponseEntity<Object> fundTransfer(@PathVariable("accNoFrom") long accNoFrom, @PathVariable("accNoTo") long accNoTo,
			@PathVariable("amount") double amount) throws AccountNotFound, NotEnoughBalance {
		double updatedbal = service.fundTransfer(accNoFrom, accNoTo, amount);
			return new ResponseEntity<Object>(updatedbal,HttpStatus.OK);
 
	}
}
