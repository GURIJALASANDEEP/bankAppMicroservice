package com.fis.transservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.transservice.model.Transaction;

public interface TransactionDao  extends JpaRepository<Transaction, Integer>{

//	public List<Cart> getAll();
//	public boolean addToCart(Cart item);
//	public boolean delete(int id);
//	public boolean deleteAll();
	
	@Query("delete Transaction t where t.transId = ?1")
	@Modifying
	public int deleteTransaction(int transId);
	
}
