package com.fis.transservice;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.transservice.model.Transaction;
import com.fis.transservice.service.TransactionService;
import com.fis.transservice.dao.TransactionDao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fis.transservice.exception.NoRecordsException;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	TransactionDao dao;
	
	@Autowired
	TransactionService service;


	
	@Test
	public void testAddTransaction() {
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		boolean res = service.addTransaction(transaction);
		System.out.println(res);
		assertTrue(res);
	}
	
	
	@Test
	@DisplayName("Delete Transaction")
	public void testDeleteTransaction() throws NoRecordsException{
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		
	
		try {
			Optional<Transaction> custList=Optional.of(transaction);

			Mockito.when(dao.findById(transaction.getTransId())).thenReturn(custList);
		Mockito.when(dao.deleteTransaction(transaction.getTransId())).thenReturn(1);		
		boolean res = service.deleteTransaction(transaction.getTransId());
		assertTrue(res);
		}
		catch (NoRecordsException e){
        	e.getMessage();
        	
        }
	}
	
	
	
	@Test
	@DisplayName("View Transaction By Id- Successful")
	public void getAll() throws NoRecordsException{
 
		Transaction transaction = new Transaction(12367,5678,4567,LocalDateTime.now(), "withdraw");
		Mockito.when(dao.save(transaction)).thenReturn(transaction);
		List<Transaction> transList=new ArrayList<Transaction>();
		List<Transaction> retransList= new ArrayList<Transaction>();
        try {
        Mockito.when(dao.findAll()).thenReturn(transList);
       	retransList = service.getAll();
       	assertEquals(transList, retransList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
		

}
