package com.fis.custservice;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.validation.annotation.Validated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import static org.junit.jupiter.api.Assertions.assertEquals;

import com.fis.custservice.model.Customer;
import com.fis.custservice.service.CustomerService;
import com.fis.custservice.dao.CustomerDao;

import static org.junit.jupiter.api.Assertions.assertTrue;

import com.fis.custservice.exception.NoRecordsException;

@SpringBootTest
class BankAppApplication {
	
	@MockBean
	CustomerDao dao;
	
	@Autowired
	CustomerService service;


	
	@Test
	public void testAddCustomer() {
		Customer customer = new Customer(1,"sandeep",new Date(), 456785677l, "san@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = service.addCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	public void testUpdateCustomer() {
		Customer customer = new Customer(1,"sandeep",new Date(), 456785677l, "san@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		boolean res = service.updateCustomer(customer);
		System.out.println(res);
		assertTrue(res);
	}
	
	@Test
	@DisplayName("Delete Customer")
	public void testDeleteCustomer() throws NoRecordsException{
		Customer customer = new Customer(1,"sandeep",new Date(), 456785677l, "san@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		
		try {
			Optional<Customer> custList=Optional.of(customer);
	
			Mockito.when(dao.findById(customer.getCustId())).thenReturn(custList);
		Mockito.when(dao.deleteCustomer(customer.getCustId())).thenReturn(1);		
		boolean res = service.deleteCustomer(customer.getCustId());
		assertTrue(res);
		}
		catch (NoRecordsException e){
        	e.getMessage();
        	
        }
	}
	
	
	
	@Test
	@DisplayName("View Customer- Successful")
	public void getAll() throws NoRecordsException{
 
		Customer customer = new Customer(1,"sandeep",new Date(), 456785677l, "san@gmail.com", "fcgvhb");
		Mockito.when(dao.save(customer)).thenReturn(customer);
		List<Customer> custList=new ArrayList<Customer>();
		List<Customer> recustList= new ArrayList<Customer>();
        try {
        Mockito.when(dao.findAll()).thenReturn(custList);
       	recustList = service.getAll();
       	assertEquals(custList, recustList);
        }
        catch (NoRecordsException e){
        	e.getMessage();
        	
        }
       
	}
	
	
	
	


}
