package com.fis.custservice.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.fis.custservice.model.Customer;

public interface CustomerDao  extends JpaRepository<Customer, Integer>{

//	public List<Cart> getAll();
//	public boolean addToCart(Cart item);
//	public boolean delete(int id);
//	public void deleteAll();
	
	@Query("delete Customer c where c.custId = ?1")
	@Modifying
	public int deleteCustomer(int custId);
	
}
