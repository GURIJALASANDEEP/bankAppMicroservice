package com.fis.custservice.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.custservice.dao.CustomerDao;
import com.fis.custservice.exception.CustomerNotFound;
import com.fis.custservice.exception.NoRecordsException;
import com.fis.custservice.model.Customer;

@Service
@Transactional
public class CustomerService {

	@Autowired
	private CustomerDao dao;
	
	public boolean addCustomer(Customer cust) {
		Customer custdb  =	dao.save(cust);
		if(custdb!=null)
			return true;
		else
			return false;
		}
	
	public boolean updateCustomer(Customer cust) {
		Customer custdb  =	dao.save(cust);
		if(custdb!=null)
			return true;
		else
			return false;
		}
	
	public List<Customer> getAll()
	{
		List<Customer> list=dao.findAll();
		if(list.isEmpty()) {
			throw new NoRecordsException("No records found");
		}
		else {
			return list;
		}
	}
	
	
	
	public boolean deleteCustomer(int custId)
	{
		
		Optional<Customer> custdb=dao.findById(custId);
		Customer custdb1=custdb.get();
		if(custdb1!=null) {
			dao.deleteCustomer(custId);
			return true;
			}
		else {
			throw new NoRecordsException("No record to delete");
		}
	}
	public boolean deleteAll() {
		dao.deleteAll();
		return true;
	}
}
