package com.fis.custservice.exception;

public class CustomerNotFound extends Exception {

	public CustomerNotFound(String message) {
		super(message);
	}

}
